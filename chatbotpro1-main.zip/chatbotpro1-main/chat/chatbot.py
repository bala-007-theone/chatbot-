# Install required packages first:
# pip install scikit-learn nltk

from sklearn.feature_extraction.text import CountVectorizer
from sklearn.naive_bayes import MultinomialNB
import random

# --- 1. Training data ---
# Example phrases for each intent
training_sentences = [
    "hello", "hi", "hey", "good morning", "good afternoon",
    "bye", "goodbye", "see you later", "see ya",
    "how are you", "how’s it going", "what’s up",
    "thank you", "thanks", "much appreciated",
    "what is your name", "who are you", "tell me your name"
]

training_labels = [
    "greeting", "greeting", "greeting", "greeting", "greeting",
    "goodbye", "goodbye", "goodbye", "goodbye",
    "how_are_you", "how_are_you", "how_are_you",
    "thanks", "thanks", "thanks",
    "name", "name", "name"
]

# --- 2. Vectorize the text (convert words to numbers) ---
vectorizer = CountVectorizer()
X = vectorizer.fit_transform(training_sentences)

# --- 3. Train the ML model ---
model = MultinomialNB()
model.fit(X, training_labels)

# --- 4. Define responses for each intent ---
responses = {
    "greeting": ["Hello! 👋", "Hi there!", "Hey! How can I help you?"],
    "goodbye": ["Goodbye! 👋", "See you later!", "Bye! Have a nice day!"],
    "how_are_you": ["I'm great, thanks for asking!", "Doing well! How about you?"],
    "thanks": ["You're welcome!", "No problem!", "Glad I could help!"],
    "name": ["I'm your friendly chatbot 🤖", "You can call me ChatBot!"]
}

# --- 5. Chat loop ---
print("🤖 Chatbot: Hi! Type 'quit' to exit.")
while True:
    user_input = input("You: ")
    if user_input.lower() == "quit":
        print("🤖 Chatbot: Goodbye! 👋")
        break

    # Convert input to vector
    X_test = vectorizer.transform([user_input])
    
    # Predict intent
    predicted_intent = model.predict(X_test)[0]
    
    # Respond with a random response for variety
    bot_reply = random.choice(responses[predicted_intent])
    print("🤖 Chatbot:", bot_reply)

